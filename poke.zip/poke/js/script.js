const typeColor = {
    bug: '#26de81',
    dragon: '#ffeaa7',
    electric: '#fed330',
    fairy: '#ff0069',
    fighting: '#30336b',
    fire: '#f0932b',
    flying: '#81ecec',
    grass: '#00b894',
    ground: '#efb549',
    ghost: '#a55eea',
    ice: '#74b9ff',
    normal: '#95afc0',
    poison: '#6c5ce7',
    psychic: '#a29bfe',
    dark: '#2d3436',
    water: '#0190ff',
    rock: '#964b00',
    steel: '#8c8a84'
}
const url = "https://pokeapi.co/api/v2/pokemon/"
//const card = document.getElementById('card')
/**/const container = document.querySelector('.container')
/**/const filterUl = document.querySelector('.ks-cboxtags')

//fazendo sistema q mostra todos os card na tela ou pelo menos 3
let getFilter = () => {
    
    let genUrl = url.replace('pokemon/','generation/')
    fetch(genUrl).then(response=>response.json()).then((data)=>{
        for (let i = 1; i < data.results.length+1; i++) {
            let finalUrl = genUrl + i
            fetch(finalUrl).then(response=>response.json()).then((data)=>generateFilter(data))
        }
    })
    getPokeData()
}

let generateFilter = (data) => {
    const name = data.main_region.name[0].toUpperCase() + data.main_region.name.slice(1)
    const gen = data.name.replace('eration','')
    let orderPokeNumber = []
    data.pokemon_species.forEach(element => {
        orderPokeNumber.push(parseInt(element.url.replace('https://pokeapi.co/api/v2/pokemon-species/','').replace('/','')))
    });
    orderPokeNumber.sort((a, b) => a - b)
    const firstPoke = orderPokeNumber[0]
    const lastPoke = orderPokeNumber[orderPokeNumber.length-1]
    const id = `${firstPoke}-${lastPoke}`.toString()
    let validation
    if(name=='Kanto'){
        validation = 'checked'
    }else{
        validation = ''
    }
    const htmlFilter = `<li>
                            <input type="checkbox" class='filterCheckbox' id="${id}" onclick='verifyFilter(checked,${firstPoke},${lastPoke},"${id}")' ${validation}>
                            <label for="${id}">${name} (${gen})</label>
                        </li>`
    filterUl.innerHTML += htmlFilter
}

let resetFilter = () => {
    document.querySelectorAll('.filterCheckbox').forEach(element => {
        if(element.id == '1-151'){
            element.checked = true
        }else{
            element.checked = false
        }
    })
    getPokeData()
    document.querySelector('.search').value = ''
}

let verifyFilter = (check, firstPoke, lastPoke, id) => {
    if(check){
        if(JSON.stringify(document.getElementById('search')) != 'null'){
            document.querySelector('.search').value = ''
            document.getElementById('search').remove()
        }
        getPokeData(firstPoke,lastPoke,false)
    }else{
        deleteFilter(id)
    }
}

let showFilter = () => {
    const filter = document.querySelector('.filter')
    if(filter.style.display == ''){
        document.querySelector('.btnFilter').style.boxShadow = '0 15px 0 5px rgb(247, 250, 81)';
        filter.style.display = 'flex'
        return true
    }
    document.querySelector('.btnFilter').style.boxShadow = '';
    filter.style.display = ''
}

let deleteFilter = (id) => {
    console.log(id)
    const genPoke = id.split('-')
    for (let i = parseInt(genPoke[0]); i < parseInt(genPoke[1])+1; i++) {
        document.getElementById(i).remove()
        
    }
}

let getPokeData = (firstPoke=1, lastPoke=8, validation=true) => {
    if(validation){
        container.innerHTML = ''
    }
    for (let i = firstPoke; i < lastPoke+1; i++) {
        let finalUrl = url + i
        fetch(finalUrl).then(response=>response.json()).then((data)=>generateCard(data))
    }   
}

let generateCard = (data, difId=false) => {
    let id;
    if(difId){
        id = 'search'
    }else{
        id = data.id
    }
    
    const hp = data.stats[0].base_stat
    const imgSrc = data.sprites.other.dream_world.front_default
    const pokeName = data.name[0].toUpperCase() + data.name.slice(1)
    const statAttack = data.stats[1].base_stat
    const statDefense = data.stats[2].base_stat
    const statSpeed = data.stats[5].base_stat
    const htmlCard = `<div class='card main baseForm' id='${id}' onclick='showDetails(${data.id})' ondblclick='flipCard("${id}")'>
    <div class="card" id="back">
    <img class='logo' src="https://logodownload.org/wp-content/uploads/2017/08/pokemon-logo-8.png">
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Pokebola-pokeball-png-0.png/769px-Pokebola-pokeball-png-0.png">
    <img class='logo' src="https://logodownload.org/wp-content/uploads/2017/08/pokemon-logo-8.png">
    </div><div class='body'>
    <p class="hp">
    <span>HP</span>
    ${hp}
</p>
<div class='poke-img'>
    <img src="${imgSrc}">
</div>
<h2 class="poke-name">${pokeName}</h2>
<div class='abilities'></div>
<div class="types">
</div>
<div class="stats">
    <div>
        <h3>${statAttack}</h3>
        <p>Attack</p>
    </div>
    <div>
        <h3>${statDefense}</h3>
        <p>Defense</p>
    </div>
    <div>
        <h3>${statSpeed}</h3>
        <p>Speed</p>
    </div></div></div>`;
    
    container.innerHTML += htmlCard
    
    appendTypes(id, data.types)
    styleCard(id, data.types)
}

let showDetails = (id) =>{
    let element;
    if(document.getElementById(id) == null){
        id = 'search'
        element = document.getElementById(id)
    }else{
        element = document.getElementById(id)
    }

    if(container.getElementsByClassName('details').length == 1){
        if(container.getElementsByClassName('details')[0].id == id){
            toggleDetails(element,'0% 50%', '50% 0%')
            let child = element.querySelector('.abilities').childNodes
            for (let i = child.length-1; i > -1; i--) {
                element.querySelector('.abilities').removeChild(child[i])
            }
        }else{
            const otherElement = container.getElementsByClassName('details')[0]
            toggleDetails(otherElement, '0% 50%', '50% 0%')
            let child = otherElement.querySelector('.abilities').childNodes
            for (let i = child.length-1; i > -1; i--) {
                otherElement.querySelector('.abilities').removeChild(child[i])
            }
            
            toggleDetails(element,'50% 0%','0% 50%')
            showAbilities(element.querySelector('.poke-name').innerHTML, element.id)
        }
    }else{
        toggleDetails(element,'50% 0%','0% 50%')
        showAbilities(element.querySelector('.poke-name').innerHTML, element.id)
    }
    
}
let showAbilities = (id, typeId) => {
    let element;
    if(typeId == 'search'){
        element = document.getElementById('search')
    }else{
        element = document.getElementById(typeId)
    }
    const finalUrl = url+ id.toLowerCase()
        fetch(finalUrl).then(response=>response.json()).then((data)=>{
            data.abilities.forEach(item => {    
                let span = document.createElement("span")
                span.textContent = item.ability.name
                element.querySelector('.abilities').appendChild(span)
            });
        })
}
let toggleDetails = (element, v1replace, v2replace) =>{
    element.classList.toggle('details')
    element.classList.toggle('baseForm')
    element.style.background = element.style.background.replace(v1replace,v2replace)
}

let appendTypes = (id, types) => {
    types.forEach(item => {
        let span = document.createElement("span")
        span.textContent = item.type.name
        document.getElementById(id).querySelector('.types').appendChild(span)
    });
}
let styleCard = (id, color) => {
    const card = document.getElementById(id)
    card.style.background = `radial-gradient(circle at 50% 0%, ${typeColor[color[0].type.name]} 40%, #ffffff 40%)`
    card.querySelectorAll('.types span').forEach(type => {
        type.style.backgroundColor = typeColor[type.innerHTML]
    })

}
let flipCard = (id) => {
    const element = document.getElementById(id)
    console.log(id)
    if(element.querySelector('#back').style.display == ''){
        element.querySelector(`#back`).style.display = 'flex'
        element.style.transform = 'rotateY(180deg)'
    }else{
        element.querySelector(`#back`).style.display = ''
        element.style.transform = 'rotateY(0deg)'
    }
}
let searchPoke = (pokemon) => {
    if(pokemon==''){
        return false
    }
    let finalUrl = url + pokemon.toLowerCase()
    fetch(finalUrl).then(response=>response.json())/*.catch(()=>{
        getPokeData()
        return true
    })*/.then((data)=>{
        document.querySelectorAll('.filterCheckbox').forEach(element => {
            element.checked = false
        })
        container.innerHTML = '';
        generateCard(data,true)
    })
}
/*const btn = document.getElementById('btn')


let getPokeData = ()=>{
    let id = Math.floor(Math.random() * 250 + 1)
    let finalUrl = url + id
    fetch(finalUrl).then((response)=>response.json()).then((data)=>generateCard(data))
}

let generateCard = (data) => {
    console.log(data.sprites)
    const hp = data.stats[0].base_stat
    const imgSrc = data.sprites.other.dream_world.front_default
    const pokeName = data.name[0].toUpperCase() + data.name.slice(1)
    const statAttack = data.stats[1].base_stat
    const statDefense = data.stats[2].base_stat
    const statSpeed = data.stats[5].base_stat
    
    card.innerHTML =   `<p class="hp">
                            <span>HP</span>
                            ${hp}
                        </p>
                        <img src="${imgSrc}">
                        <h2 class="poke-name">${pokeName}</h2>
                        <div class="types">
                        </div>
                        <div class="stats">
                            <div>
                                <h3>${statAttack}</h3>
                                <p>Attack</p>
                            </div>
                            <div>
                                <h3>${statDefense}</h3>
                                <p>Defense</p>
                            </div>
                            <div>
                                <h3>${statSpeed}</h3>
                                <p>Speed</p>
                            </div>`;
    appendTypes(data.types)
    styleCard(data.types)
}
let appendTypes = (types) => {
    types.forEach(item => {
        let span = document.createElement("span")
        span.textContent = item.type.name
        document.querySelector(".types").appendChild(span)
    });
}
let styleCard = (color) => {
    card.style.background = `radial-gradient(circle at 50% 0%, ${typeColor[color[0].type.name]} 40%, #ffffff 40%)`
    card.querySelectorAll('.types span').forEach(type => {
        type.style.backgroundColor = typeColor[type.innerHTML]
    })

}
*/
window.addEventListener("load",getFilter)